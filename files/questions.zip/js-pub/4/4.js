var x = 42;

(function() { x += 10; })();

console.log(x);