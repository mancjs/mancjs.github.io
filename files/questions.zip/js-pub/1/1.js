var a = 10;
var b = '10';

console.log(a == b);