var object = {
  message: 'hello mancjs',
  display: function() {
    var message = 'now you are thinking!';
    console.log(this.message);
  }
};

object.display();