var add = function(number1, number2) {
  total = number1 + number2;
  return total;
};

console.log(add(10, 15));