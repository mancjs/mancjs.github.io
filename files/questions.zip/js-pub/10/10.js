var fn = function() {
  var names = ['bob', 'john', 'jim'];

  for (name in names) {
    console.log(name);
  }
};

fn();

console.log((global || window).name);