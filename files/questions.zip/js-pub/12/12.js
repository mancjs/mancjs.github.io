var fn = function()
{
  return
  {
    data: 'hello mancjs!'
  };
};

console.log(fn().data);