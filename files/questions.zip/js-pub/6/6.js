var integer = parseInt('08');

console.log(integer);