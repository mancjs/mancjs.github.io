var a = ?;
var b = ?;

var isTrue = (a === b) && ((1/a) < (1/b));

console.log(isTrue);