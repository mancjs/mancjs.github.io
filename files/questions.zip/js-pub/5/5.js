var x = 42;

(function() { ++x; });

console.log(x);