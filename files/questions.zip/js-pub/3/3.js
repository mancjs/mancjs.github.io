var a = 0.1;
var b = 0.2;
var total = 0.3;

console.log(a + b === total);